export { default as Browsing } from "./browsing";
export { default as Details } from "./browsing/details";
export { default as Clothes } from "./browsing/clothes";
export { default as Mobile } from "./browsing/mobile";
