import React from "react";
import "./styles.css";

export default function Clothes(props) {
  return <div>Clothes</div>;
}
